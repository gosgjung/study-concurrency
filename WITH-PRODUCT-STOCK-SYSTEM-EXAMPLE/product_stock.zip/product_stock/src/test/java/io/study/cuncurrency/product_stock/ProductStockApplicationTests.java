package io.study.cuncurrency.product_stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
